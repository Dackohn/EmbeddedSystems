/*
 * dev_hw_stdio.h
 *
 * Hardware-backed FILE stream abstraction:
 * - fputc() is used to control LEDs using specific command characters
 * - fgetc() is used to read button transition events (pressed/released)
 *
 * This allows tasks to interact with button + LEDs via stdio-like calls,
 * while low-level GPIO access remains inside this module.
 */

#pragma once
#include <stdio.h>
#include <stdint.h>

/* Encoded bytes used as LED commands for hw_putchar(). */
#define HW_LED_GREEN_ON    'G'
#define HW_LED_GREEN_OFF   'g'
#define HW_LED_RED_ON      'R'
#define HW_LED_RED_OFF     'r'
#define HW_LED_YELLOW_ON   'Y'
#define HW_LED_YELLOW_OFF  'y'

/* Encoded bytes returned by hw_getchar() to represent raw button edges. */
#define HW_BTN_RAW_PRESSED   '1'
#define HW_BTN_RAW_RELEASED  '0'

/* Initialize GPIO directions/pull-ups and bind FILE handlers. */
void dev_hw_stdio_init(void);

/* Get the FILE* used for button/LED IO through fgetc/fputc. */
FILE* dev_hw_stdio_stream(void);