/*
 * dev_hw_stdio.c
 *
 * Implements a custom FILE stream:
 * - Writing specific characters toggles LEDs (hw_putchar)
 * - Reading yields button transition events when state changes (hw_getchar)
 *
 * This keeps register-level GPIO operations isolated in one module.
 */

#include "dev_hw_stdio.h"
#include "../board_select.h"
#include "../app_config.h"
#include <avr/io.h>

/* Helper: configure a pin as output. */
static inline void pin_output(volatile uint8_t* ddr, uint8_t bit) { *ddr |= (1u << bit); }

/* Helper: configure a pin as input. */
static inline void pin_input(volatile uint8_t* ddr, uint8_t bit)  { *ddr &= (uint8_t)~(1u << bit); }

/* Helper: write logic value to output pin. */
static inline void pin_write(volatile uint8_t* port, uint8_t bit, uint8_t v) {
    if (v) *port |= (1u << bit);
    else   *port &= (uint8_t)~(1u << bit);
}

/* Helper: read logic level from input pin register. */
static inline uint8_t pin_read(volatile uint8_t* pinr, uint8_t bit) {
    return (*pinr & (1u << bit)) ? 1u : 0u;
}

/* Read "pressed" as a normalized boolean, independent of wiring polarity. */
static inline uint8_t read_pressed_level(void) {
    uint8_t level = pin_read(&BTN_PINR, BTN_BIT);
#if BUTTON_ACTIVE_LOW
    /* Active-low: electrical 0 means pressed. */
    return (level == 0u) ? 1u : 0u;
#else
    /* Active-high: electrical 1 means pressed. */
    return (level != 0u) ? 1u : 0u;
#endif
}

/* FILE putc handler: interpret bytes as LED commands. */
static int hw_putchar(char c, FILE* stream) {
    (void)stream;

    switch (c) {
        case HW_LED_GREEN_ON:   pin_write(&LEDG_PORT, LEDG_BIT, 1u); break;
        case HW_LED_GREEN_OFF:  pin_write(&LEDG_PORT, LEDG_BIT, 0u); break;

        case HW_LED_RED_ON:     pin_write(&LEDR_PORT, LEDR_BIT, 1u); break;
        case HW_LED_RED_OFF:    pin_write(&LEDR_PORT, LEDR_BIT, 0u); break;

        case HW_LED_YELLOW_ON:  pin_write(&LEDY_PORT, LEDY_BIT, 1u); break;
        case HW_LED_YELLOW_OFF: pin_write(&LEDY_PORT, LEDY_BIT, 0u); break;

        default:
            /* Ignore anything that is not a hardware command. */
            break;
    }
    return 0;
}

/*
 * FILE getc handler:
 * - Non-blocking edge/event reader: returns only on state change.
 * - Returns EOF if no transition occurred.
 * - First call returns current state to allow clean initialization.
 */
static int hw_getchar(FILE* stream) {
    (void)stream;

    static uint8_t last_pressed = 0;
    static uint8_t initialized = 0;

    uint8_t pressed = read_pressed_level();

    if (!initialized) {
        initialized = 1;
        last_pressed = pressed;
        return pressed ? (int)HW_BTN_RAW_PRESSED : (int)HW_BTN_RAW_RELEASED;
    }

    if (pressed != last_pressed) {
        last_pressed = pressed;
        return pressed ? (int)HW_BTN_RAW_PRESSED : (int)HW_BTN_RAW_RELEASED;
    }

    /* No change -> EOF indicates "no new edge". */
    return _FDEV_EOF;
}

static FILE g_hw_stream;

void dev_hw_stdio_init(void) {
    /* Button input pin. */
    pin_input(&BTN_DDR, BTN_BIT);

#if BUTTON_ACTIVE_LOW
    /* Enable pull-up resistor for active-low wiring (button to GND). */
    BTN_PORT |= (1u << BTN_BIT);
#endif

    /* LED output pins. */
    pin_output(&LEDG_DDR, LEDG_BIT);
    pin_output(&LEDR_DDR, LEDR_BIT);
    pin_output(&LEDY_DDR, LEDY_BIT);

    /* Default state: all LEDs OFF. */
    pin_write(&LEDG_PORT, LEDG_BIT, 0u);
    pin_write(&LEDR_PORT, LEDR_BIT, 0u);
    pin_write(&LEDY_PORT, LEDY_BIT, 0u);

    /* Bind handlers to FILE stream (read + write). */
    fdev_setup_stream(&g_hw_stream, hw_putchar, hw_getchar, _FDEV_SETUP_RW);
}

FILE* dev_hw_stdio_stream(void) {
    return &g_hw_stream;
}