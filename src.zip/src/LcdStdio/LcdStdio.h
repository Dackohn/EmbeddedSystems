#ifndef LCD_STDIO_H
#define LCD_STDIO_H

#include <stdint.h>
#include <stdio.h>
#include "LcdHd44780/LcdHd44780.h"

typedef struct
{
    LcdHd44780 Driver;
    FILE Stream;
    uint8_t Col;
    uint8_t Row;
} LcdStdio;

void LcdStdio_Init(LcdStdio *ctx, const LcdHd44780 *cfg);
FILE *LcdStdio_GetFile(LcdStdio *ctx);

#endif