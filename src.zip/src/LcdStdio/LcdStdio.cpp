#include "LcdStdio.h"

static LcdStdio *GlobalLcd;

static int Lcd_PutChar(char c, FILE *stream)
{
    (void)stream;

    if (c == '\n')
    {
        GlobalLcd->Row ^= 1;
        GlobalLcd->Col = 0;
        LcdHd44780_SetCursor(&GlobalLcd->Driver, 0, GlobalLcd->Row);
        return 0;
    }

    LcdHd44780_WriteChar(&GlobalLcd->Driver, c);
    GlobalLcd->Col++;

    if (GlobalLcd->Col >= 16)
    {
        GlobalLcd->Col = 0;
        GlobalLcd->Row ^= 1;
        LcdHd44780_SetCursor(&GlobalLcd->Driver, 0, GlobalLcd->Row);
    }

    return 0;
}

void LcdStdio_Init(LcdStdio *ctx, const LcdHd44780 *cfg)
{
    ctx->Driver = *cfg;
    ctx->Col = 0;
    ctx->Row = 0;

    GlobalLcd = ctx;

    LcdHd44780_Init(&ctx->Driver);
    LcdHd44780_Clear(&ctx->Driver);

        fdev_setup_stream(&ctx->Stream, Lcd_PutChar, NULL, _FDEV_SETUP_WRITE);
}

FILE *LcdStdio_GetFile(LcdStdio *ctx)
{
    return &ctx->Stream;
}