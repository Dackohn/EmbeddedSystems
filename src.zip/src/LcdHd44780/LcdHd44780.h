#ifndef LCD_HD44780_H
#define LCD_HD44780_H

#include <stdint.h>

typedef struct
{
    volatile uint8_t *Ddr;
    volatile uint8_t *Port;

    uint8_t RsMask;
    uint8_t EnMask;

    uint8_t D4Mask;
    uint8_t D5Mask;
    uint8_t D6Mask;
    uint8_t D7Mask;
} LcdHd44780;

void LcdHd44780_Init(LcdHd44780 *lcd);
void LcdHd44780_Clear(LcdHd44780 *lcd);
void LcdHd44780_Home(LcdHd44780 *lcd);
void LcdHd44780_SetCursor(LcdHd44780 *lcd, uint8_t col, uint8_t row);
void LcdHd44780_WriteChar(LcdHd44780 *lcd, char c);
void LcdHd44780_WriteString(LcdHd44780 *lcd, const char *s);

#endif