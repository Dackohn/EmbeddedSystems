#include "LcdHd44780.h"
#include <util/delay.h>

typedef enum
{
    LcdCmd_Clear = 0x01,
    LcdCmd_Home  = 0x02,
    LcdCmd_EntryMode = 0x06,
    LcdCmd_DisplayOn = 0x0C,
    LcdCmd_FunctionSet4Bit2Line = 0x28
} LcdCommand;

static void Lcd_SetOutputPins(LcdHd44780 *lcd)
{
    *(lcd->Ddr) |= lcd->RsMask | lcd->EnMask |
                  lcd->D4Mask | lcd->D5Mask | lcd->D6Mask | lcd->D7Mask;
}

static void Lcd_SetRs(LcdHd44780 *lcd, uint8_t isData)
{
    if (isData)
        *(lcd->Port) |= lcd->RsMask;
    else
        *(lcd->Port) &= (uint8_t)~lcd->RsMask;
}

static void Lcd_PulseEnable(LcdHd44780 *lcd)
{
    *(lcd->Port) |= lcd->EnMask;
    _delay_us(1);
    *(lcd->Port) &= (uint8_t)~lcd->EnMask;
    _delay_us(50);
}

static void Lcd_Write4Bits(LcdHd44780 *lcd, uint8_t nibble)
{
    // Curăță liniile D4..D7
    *(lcd->Port) &= (uint8_t)~(lcd->D4Mask | lcd->D5Mask | lcd->D6Mask | lcd->D7Mask);

    if (nibble & 0x01) *(lcd->Port) |= lcd->D4Mask;
    if (nibble & 0x02) *(lcd->Port) |= lcd->D5Mask;
    if (nibble & 0x04) *(lcd->Port) |= lcd->D6Mask;
    if (nibble & 0x08) *(lcd->Port) |= lcd->D7Mask;

    Lcd_PulseEnable(lcd);
}

static void Lcd_Send(LcdHd44780 *lcd, uint8_t value, uint8_t isData)
{
    Lcd_SetRs(lcd, isData);
    Lcd_Write4Bits(lcd, (uint8_t)(value >> 4));
    Lcd_Write4Bits(lcd, (uint8_t)(value & 0x0F));
}

static void Lcd_Command(LcdHd44780 *lcd, uint8_t cmd)
{
    Lcd_Send(lcd, cmd, 0);
    if (cmd == LcdCmd_Clear || cmd == LcdCmd_Home)
    {
        _delay_ms(2);
    }
}

void LcdHd44780_Init(LcdHd44780 *lcd)
{
    Lcd_SetOutputPins(lcd);

    _delay_ms(50);

    // Init în 4-bit conform datasheet
    Lcd_SetRs(lcd, 0);
    Lcd_Write4Bits(lcd, 0x03);
    _delay_ms(5);
    Lcd_Write4Bits(lcd, 0x03);
    _delay_us(150);
    Lcd_Write4Bits(lcd, 0x03);
    _delay_us(150);
    Lcd_Write4Bits(lcd, 0x02); // 4-bit
    _delay_us(150);

    Lcd_Command(lcd, LcdCmd_FunctionSet4Bit2Line);
    Lcd_Command(lcd, LcdCmd_DisplayOn);
    Lcd_Command(lcd, LcdCmd_Clear);
    Lcd_Command(lcd, LcdCmd_EntryMode);
}

void LcdHd44780_Clear(LcdHd44780 *lcd)
{
    Lcd_Command(lcd, LcdCmd_Clear);
}

void LcdHd44780_Home(LcdHd44780 *lcd)
{
    Lcd_Command(lcd, LcdCmd_Home);
}

void LcdHd44780_SetCursor(LcdHd44780 *lcd, uint8_t col, uint8_t row)
{
    // Mapare clasică 16x2: r0=0x00, r1=0x40
    const uint8_t RowOffsets[2] = { 0x00, 0x40 };
    uint8_t addr = (uint8_t)(0x80 | (RowOffsets[row & 0x01] + col));
    Lcd_Command(lcd, addr);
}

void LcdHd44780_WriteChar(LcdHd44780 *lcd, char c)
{
    Lcd_Send(lcd, (uint8_t)c, 1);
}

void LcdHd44780_WriteString(LcdHd44780 *lcd, const char *s)
{
    while (*s)
    {
        LcdHd44780_WriteChar(lcd, *s++);
    }
}