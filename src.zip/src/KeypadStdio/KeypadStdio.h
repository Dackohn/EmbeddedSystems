#ifndef KEYPAD_STDIO_H
#define KEYPAD_STDIO_H

#include <stdint.h>
#include <stdio.h>

typedef struct
{
    volatile uint8_t *Ddr;
    volatile uint8_t *Port;
    volatile uint8_t *Pin;

    uint8_t RowMask[4];
    uint8_t ColMask[4];

    char KeyMap[4][4];

    FILE Stream;
} KeypadStdio;

void KeypadStdio_Init(KeypadStdio *ctx);
FILE *KeypadStdio_GetFile(KeypadStdio *ctx);

#endif