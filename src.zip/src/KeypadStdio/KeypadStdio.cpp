#include "KeypadStdio.h"
#include <util/delay.h>

#define DebounceDelayMs 25
#define KeypadRows 4
#define KeypadCols 4

static KeypadStdio *GlobalKeypad;

static char Keypad_ReadKey(KeypadStdio *ctx)
{
    for (uint8_t r = 0; r < KeypadRows; r++)
    {
        for (uint8_t i = 0; i < KeypadRows; i++)
            *(ctx->Port) |= ctx->RowMask[i];

        *(ctx->Port) &= ~(ctx->RowMask[r]);
        _delay_us(5);

        uint8_t pins = *(ctx->Pin);

        for (uint8_t c = 0; c < KeypadCols; c++)
        {
            if ((pins & ctx->ColMask[c]) == 0)
            {
                _delay_ms(DebounceDelayMs);
                while ((*(ctx->Pin) & ctx->ColMask[c]) == 0);
                return ctx->KeyMap[r][c];
            }
        }
    }
    return 0;
}

static int Keypad_GetChar(FILE *stream)
{
    (void)stream;

    char key = 0;
    while ((key = Keypad_ReadKey(GlobalKeypad)) == 0);

    if (key == '#')
        return '\n';   // ENTER pentru scanf

    return key;
}

void KeypadStdio_Init(KeypadStdio *ctx)
{
    GlobalKeypad = ctx;

    for (uint8_t r = 0; r < 4; r++)
        *(ctx->Ddr) |= ctx->RowMask[r];

    for (uint8_t c = 0; c < 4; c++)
    {
        *(ctx->Ddr) &= ~(ctx->ColMask[c]);
        *(ctx->Port) |= ctx->ColMask[c];
    }

    fdev_setup_stream(&ctx->Stream, NULL, Keypad_GetChar, _FDEV_SETUP_READ);
}

FILE *KeypadStdio_GetFile(KeypadStdio *ctx)
{
    return &ctx->Stream;
}