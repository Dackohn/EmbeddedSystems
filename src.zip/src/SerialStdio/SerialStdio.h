#ifndef SERIAL_STDIO_H
#define SERIAL_STDIO_H

#include <stdint.h>
#include <stdio.h>

typedef struct
{
    FILE *SerialFile;
} SerialStdio;

void SerialStdio_Init(SerialStdio *ctx, uint32_t baud);
FILE *SerialStdio_GetFile(SerialStdio *ctx);

#endif