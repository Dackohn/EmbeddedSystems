#include "SerialStdio.h"
#include <avr/io.h>
#include <util/setbaud.h>

#ifndef F_CPU
#define F_CPU 16000000UL
#endif

static int SerialStdio_PutChar(char c, FILE *stream);
static int SerialStdio_GetChar(FILE *stream);

static FILE SerialStream = FDEV_SETUP_STREAM(SerialStdio_PutChar, SerialStdio_GetChar, _FDEV_SETUP_RW);

void SerialStdio_Init(SerialStdio *ctx, uint32_t baud)
{
    (void)baud; // baud e configurat prin util/setbaud via defines; păstrat pentru API stabil

    // Calcul baud (setbaud folosește BAUD macro)
    // Ca să fie “fără magic number”, BAUD se setează în build flags sau înainte de include setbaud.
    // În practică, pentru UNO poți seta BAUD=9600 direct în platformio.ini.
    // Dacă nu ai, definește BAUD aici:
#ifndef BAUD
#define BAUD 9600
#endif

#include <util/setbaud.h>

    UBRR0H = UBRRH_VALUE;
    UBRR0L = UBRRL_VALUE;

#if USE_2X
    UCSR0A |= (1U << U2X0);
#else
    UCSR0A &= ~(1U << U2X0);
#endif

    UCSR0B = (1U << RXEN0) | (1U << TXEN0);
    UCSR0C = (1U << UCSZ01) | (1U << UCSZ00); // 8N1

    ctx->SerialFile = &SerialStream;

    stdout = ctx->SerialFile;
    stdin  = ctx->SerialFile;
}

FILE *SerialStdio_GetFile(SerialStdio *ctx)
{
    return ctx->SerialFile;
}

static int SerialStdio_PutChar(char c, FILE *stream)
{
    (void)stream;

    if (c == '\n')
    {
        SerialStdio_PutChar('\r', stream);
    }

    while (!(UCSR0A & (1U << UDRE0))) { }
    UDR0 = (uint8_t)c;
    return 0;
}

static int SerialStdio_GetChar(FILE *stream)
{
    (void)stream;

    while (!(UCSR0A & (1U << RXC0))) { }
    return (int)UDR0;
}