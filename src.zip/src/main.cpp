#include <avr/io.h>
#include <string.h>
#include <stdio.h>

#include "LcdStdio/LcdStdio.h"
#include "KeypadStdio/KeypadStdio.h"
#include "LedController/LedController.h"

#define CodeLength 4

int main(void)
{
    // ---- LCD config ----
    LcdHd44780 lcdCfg = {
        .Ddr = &DDRD,
        .Port = &PORTD,
        .RsMask = (1<<PD2),
        .EnMask = (1<<PD3),
        .D4Mask = (1<<PD4),
        .D5Mask = (1<<PD5),
        .D6Mask = (1<<PD6),
        .D7Mask = (1<<PD7)
    };

    LcdStdio lcd;
    LcdStdio_Init(&lcd, &lcdCfg);

    stdout = LcdStdio_GetFile(&lcd);

    // ---- Keypad config ----
    KeypadStdio keypad = {
        .Ddr = &DDRC,
        .Port = &PORTC,
        .Pin = &PINC,
        .RowMask = {1<<PC0,1<<PC1,1<<PC2,1<<PC3},
        .ColMask = {1<<PC4,1<<PC5,1<<PC6,1<<PC7},
        .KeyMap = {
            {'1','2','3','A'},
            {'4','5','6','B'},
            {'7','8','9','C'},
            {'*','0','#','D'}
        }
    };

    KeypadStdio_Init(&keypad);
    stdin = KeypadStdio_GetFile(&keypad);

    // ---- LED-uri ----
    Led green = { &DDRB, &PORTB, (1<<PB0) };
    Led red   = { &DDRB, &PORTB, (1<<PB1) };

    Led_Init(&green);
    Led_Init(&red);

    const char validCode[CodeLength+1] = "1234";
    char input[CodeLength+1];

    while (1)
    {
        printf("Enter code:\n");

        scanf("%4s", input);   // <-- utilizare explicita scanf

        if (strcmp(input, validCode) == 0)
        {
            printf("Access OK");
            Led_On(&green);
            Led_Off(&red);
        }
        else
        {
            printf("Access FAIL");
            Led_On(&red);
            Led_Off(&green);
        }
    }
}