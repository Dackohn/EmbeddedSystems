#ifdef USE_FREERTOS

#include "rtos_tasks.h"

#include <Arduino_FreeRTOS.h>
#include <semphr.h>
#include <stdint.h>

#include "app_shared/app_shared.h"

#include "task_press_measure/task_press_measure.h"
#include "task_stats_blink/task_stats_blink.h"
#include "task_report/task_report.h"

/* Contexts */
static TaskPressMeasureCtx g_t1;
static TaskStatsBlinkCtx   g_t2;
static TaskReportCtx       g_t3;

/* Event semaphore: Task 1 -> Task 2 */
static SemaphoreHandle_t g_sem_press;

/*
 * Global mutex used to protect shared globals:
 * - g_press_event (T1 writes, T2 reads)
 * - g_stats      (T2 writes, T3 reads/resets)
 *
 * IMPORTANT: do NOT hold this while printing.
 */
SemaphoreHandle_t g_mutex_shared;

/* -----------------------------------------------------------------------
 * Task 1 — button polling + press measurement
 * ----------------------------------------------------------------------- */
static void task_button(void* arg) {
    (void)arg;

    task_press_measure_init(&g_t1, 0);

    for (;;) {
        vTaskDelay(1);

        /* Read before flag */
        uint8_t before;
        xSemaphoreTake(g_mutex_shared, portMAX_DELAY);
        before = g_press_event.last_press_valid;
        xSemaphoreGive(g_mutex_shared);

        /* Update press measurement (writes g_press_event) */
        xSemaphoreTake(g_mutex_shared, portMAX_DELAY);
        task_press_measure_run(&g_t1);
        xSemaphoreGive(g_mutex_shared);

        /* Read after flag */
        uint8_t after;
        xSemaphoreTake(g_mutex_shared, portMAX_DELAY);
        after = g_press_event.last_press_valid;
        xSemaphoreGive(g_mutex_shared);

        if (!before && after) {
            xSemaphoreGive(g_sem_press);
        }
    }
}

/* -----------------------------------------------------------------------
 * Task 2 — statistics + yellow blink engine
 * ----------------------------------------------------------------------- */
static void task_stats(void* arg) {
    (void)arg;

    task_stats_blink_init(&g_t2);

    for (;;) {
        xSemaphoreTake(g_sem_press, portMAX_DELAY);

        /* 1) Let the stats module see the press event first */
        xSemaphoreTake(g_mutex_shared, portMAX_DELAY);
        task_stats_blink_run(&g_t2);
        /* 2) Now clear the edge so the next press can be detected */
        g_press_event.last_press_valid = 0;
        xSemaphoreGive(g_mutex_shared);

        /* 3) Continue blinking sequence (it should rely on g_t2.active now) */
        while (g_t2.active) {
            xSemaphoreTake(g_mutex_shared, portMAX_DELAY);
            task_stats_blink_run(&g_t2);
            xSemaphoreGive(g_mutex_shared);

            vTaskDelay(3);
        }
    }
}

/* -----------------------------------------------------------------------
 * Task 3 — console poll + periodic report
 * The report module will lock only to copy/reset stats, then unlock and print.
 * ----------------------------------------------------------------------- */
static void task_report_rtos(void* arg) {
    (void)arg;

    task_report_init(&g_t3);

    TickType_t lastWake = xTaskGetTickCount();

    for (;;) {
        task_report_run(&g_t3);
        vTaskDelayUntil(&lastWake, pdMS_TO_TICKS(20));
    }
}

/* -----------------------------------------------------------------------
 * Create tasks + sync objects
 * ----------------------------------------------------------------------- */
void rtos_tasks_create(void) {
    g_sem_press = xSemaphoreCreateBinary();
    g_mutex_shared = xSemaphoreCreateMutex();

    if (g_sem_press == NULL || g_mutex_shared == NULL) {
        for (;;) { }
    }

    xTaskCreate(task_button,      "btn",    200,  NULL, 2, NULL);
    xTaskCreate(task_stats,       "stats",  200,  NULL, 2, NULL);
    xTaskCreate(task_report_rtos, "report", 300, NULL, 3, NULL);
}

#endif /* USE_FREERTOS */