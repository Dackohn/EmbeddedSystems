#ifdef USE_FREERTOS

#include "rtos_tasks.h"

#include <Arduino_FreeRTOS.h>
#include <semphr.h>
#include <stdio.h>

#include "app_config.h"
#include "app_shared/app_shared.h"

#include "task_press_measure/task_press_measure.h"
#include "task_stats_blink/task_stats_blink.h"
#include "task_report/task_report.h"

/* -----------------------------------------------------------------------
 * Shared state
 * ----------------------------------------------------------------------- */

static TaskPressMeasureCtx g_t1;
static TaskStatsBlinkCtx   g_t2;
static TaskReportCtx       g_t3;

/*
 * Binary semaphore: Task 1 gives it once a complete press is recorded.
 * Task 2 blocks on it, so it only wakes when there is actually work to do.
 */
static SemaphoreHandle_t g_sem_press;

/* -----------------------------------------------------------------------
 * Task 1 — button polling + press measurement
 *
 * Runs every tick (vTaskDelay(1)).
 * At 64 Hz that is ~15 ms — more than enough for 5 ms debounce.
 * All button I/O goes through dev_hw_stdio_stream() via fgetc(), exactly
 * as in the bare-metal build.
 * ----------------------------------------------------------------------- */
static void task_button(void* arg) {
    (void)arg;

    task_press_measure_init(&g_t1, 0);

    for (;;) {
        vTaskDelay(1);   /* yield one tick (~15 ms at 64 Hz) */

        uint8_t before = g_press_event.last_press_valid;

        task_press_measure_run(&g_t1);   /* reads hw stream, writes LEDs via fputc */

        uint8_t after = g_press_event.last_press_valid;

        /* A new press event was just published — wake Task 2. */
        if (!before && after) {
            xSemaphoreGive(g_sem_press);
        }
    }
}

/* -----------------------------------------------------------------------
 * Task 2 — statistics + yellow blink engine
 *
 * Sleeps until Task 1 signals a completed press, then:
 *   1. Calls task_stats_blink_run() once to consume the event and start blink.
 *   2. Loops calling it every tick until the blink sequence finishes.
 *
 * task_stats_blink_run() uses mcal_millis() internally for toggle timing,
 * so the blink intervals are wall-clock correct regardless of tick rate.
 * ----------------------------------------------------------------------- */
static void task_stats(void* arg) {
    (void)arg;

    task_stats_blink_init(&g_t2);

    for (;;) {
        /* Block forever until a press event arrives. */
        xSemaphoreTake(g_sem_press, portMAX_DELAY);

        /* Consume event + start blink, then keep driving blink engine. */
        do {
            task_stats_blink_run(&g_t2);
            if (g_t2.active) {
                vTaskDelay(1);   /* yield, come back to advance blink timing */
            }
        } while (g_t2.active);
    }
}

/* -----------------------------------------------------------------------
 * Task 3 — periodic 10-second report + console command poll
 *
 * Uses vTaskDelay(pdMS_TO_TICKS(10000)) for the 10-second period.
 * task_report_run() uses printf() → stdout → UART, and reads stdin for
 * commands — both set up in arduino_entry.c, same as bare-metal.
 * ----------------------------------------------------------------------- */
static void task_report_rtos(void* arg) {
    (void)arg;

    task_report_init(&g_t3);

    for (;;) {
        vTaskDelay(pdMS_TO_TICKS(10000));
        task_report_run(&g_t3);
    }
}

/* -----------------------------------------------------------------------
 * Create tasks + sync objects. Call once from setup().
 * Stack sizes in words (2 bytes each on AVR).
 * ----------------------------------------------------------------------- */
void rtos_tasks_create(void) {
    g_sem_press = xSemaphoreCreateBinary();

    xTaskCreate(task_button,      "btn",    150, NULL, 3, NULL);
    xTaskCreate(task_stats,       "stats",  150, NULL, 2, NULL);
    xTaskCreate(task_report_rtos, "report", 250, NULL, 1, NULL);
}

#endif /* USE_FREERTOS */