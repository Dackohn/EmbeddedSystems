#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void rtos_tasks_create(void);

#ifdef __cplusplus
}
#endif