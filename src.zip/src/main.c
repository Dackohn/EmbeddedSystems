/*
 * main.c
 *
 * System entry point:
 * - initializes UART stdio (printf/command input)
 * - initializes hardware stdio stream (button + LEDs)
 * - initializes Timer1 1ms timebase
 * - initializes task contexts
 * - creates scheduler task table (period/offset/fn/context)
 * - runs the cooperative scheduler exactly once per 1ms tick
 */

#include "app_config.h"
#include "dev_hw_stdio/dev_hw_stdio.h"
 
#include "mcal_timer1_1ms/mcal_timer1_1ms.h"
#include "mcal_uart0_stdio/mcal_uart0_stdio.h"

#include "srv_scheduler/srv_scheduler.h"

#include "task_press_measure/task_press_measure.h"
#include "task_stats_blink/task_stats_blink.h"
#include "task_report/task_report.h"

#include <avr/interrupt.h>
#include <stdio.h>

/* Task contexts hold state between runs (debounce, blink engine, etc.). */
static TaskPressMeasureCtx g_t1;
static TaskStatsBlinkCtx   g_t2;
static TaskReportCtx       g_t3;

/* Hardware initialization wrapper. */
static void hw_init(void) {
    cli();

    /* UART0 -> connect stdout/stdin to serial console. */
    mcal_uart0_stdio_init(UART_BAUD);

    /* Hardware FILE stream -> button read edges + LED commands via stdio. */
    dev_hw_stdio_init();

    /* Timer1 -> 1ms interrupt tick and ms counter. */
    mcal_timer1_init_1ms();

    sei();
}

int main(void) {
    hw_init();

    /* Startup messages (visible in the serial monitor). */
    printf("READY: Button press monitor\n");
    printf("Commands: stats | reset\n");

    uint32_t now = mcal_millis();

    /* Initialize all tasks. */
    task_press_measure_init(&g_t1, now);
    task_stats_blink_init(&g_t2);
    task_report_init(&g_t3);

    /* Cooperative scheduler task table. */
    TaskDesc_t tasks[] = {
        { TASK1_PERIOD_MS, TASK1_OFFSET_MS, 0, task_press_measure_run, &g_t1 },
        { TASK2_PERIOD_MS, TASK2_OFFSET_MS, 0, task_stats_blink_run,   &g_t2 },
        { TASK3_PERIOD_MS, TASK3_OFFSET_MS, 0, task_report_run,        &g_t3 },
    };

    Scheduler_t sch;
    srv_scheduler_init(&sch, tasks, (uint8_t)(sizeof(tasks)/sizeof(tasks[0])), now);

    /* Run: one scheduler dispatch per 1ms tick. */
    while (1) {
        if (mcal_consume_tick()) {
            uint32_t t = mcal_millis();
            srv_scheduler_run_one(&sch, t);
        }
    }
}