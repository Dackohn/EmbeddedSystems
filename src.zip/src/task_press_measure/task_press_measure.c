/*
 * task_press_measure.c
 *
 * Task 1:
 * - reads raw button edges from dev_hw_stdio FILE stream (non-blocking)
 * - applies debounce using DEBOUNCE_MS window
 * - measures press duration between debounced PRESS and RELEASE
 * - publishes event (duration + type) to g_press_event
 * - turns ON green (short) or red (long) LED after release
 */

#include "task_press_measure.h"
#include "../app_config.h"
#include "../mcal_timer1_1ms/mcal_timer1_1ms.h"
#include "../app_shared/app_shared.h"
#include "../dev_hw_stdio/dev_hw_stdio.h"
#include <stdio.h>

/* Read raw transition from hw stream:
 * - returns current_raw if no new transition is available (EOF)
 * - returns 1 for pressed event, 0 for released event
 */
static inline uint8_t hw_read_raw(FILE* hw, uint8_t current_raw) {
    int ch = fgetc(hw);
    if (ch == EOF) return current_raw;
    if (ch == (int)HW_BTN_RAW_PRESSED)  return 1u;
    if (ch == (int)HW_BTN_RAW_RELEASED) return 0u;
    return current_raw;
}

void task_press_measure_init(TaskPressMeasureCtx* ctx, uint32_t now_ms) {
    FILE* hw = dev_hw_stdio_stream();

    /* Reset timing and state. */
    ctx->press_start_ms = 0;
    ctx->pressed = 0;

    /* Initialize debounce state from current hardware value. */
    ctx->raw_level = hw_read_raw(hw, 0u);
    ctx->stable_level = ctx->raw_level;
    ctx->last_change_ms = now_ms;

    /* Ensure classification LEDs start OFF. */
    fputc(HW_LED_GREEN_OFF, hw);
    fputc(HW_LED_RED_OFF, hw);
}

void task_press_measure_run(void* vctx) {
    TaskPressMeasureCtx* ctx = (TaskPressMeasureCtx*)vctx;
    uint32_t now = mcal_millis();
    FILE* hw = dev_hw_stdio_stream();

    /* Step 1: get raw level updates (edge driven). */
    uint8_t new_raw = hw_read_raw(hw, ctx->raw_level);
    if (new_raw != ctx->raw_level) {
        ctx->raw_level = new_raw;
        ctx->last_change_ms = now; /* raw changed: restart debounce window */
    }

    /* Step 2: debounce: accept change only if stable for DEBOUNCE_MS. */
    if (ctx->stable_level != ctx->raw_level) {
        if ((uint32_t)(now - ctx->last_change_ms) >= (uint32_t)DEBOUNCE_MS) {
            ctx->stable_level = ctx->raw_level;

            if (ctx->stable_level) {
                /* Debounced PRESS: start timing. */
                ctx->press_start_ms = now;
                ctx->pressed = 1u;

                /* Clear previous classification while button is being used. */
                fputc(HW_LED_GREEN_OFF, hw);
                fputc(HW_LED_RED_OFF, hw);
            } else {
                /* Debounced RELEASE: compute duration and publish event. */
                if (ctx->pressed) {
                    ctx->pressed = 0u;

                    uint32_t dur = now - ctx->press_start_ms;
                    uint8_t is_long = (dur >= (uint32_t)SHORT_PRESS_THRESHOLD_MS) ? 1u : 0u;

                    /* Publish for Task 2. */
                    g_press_event.last_press_ms = dur;
                    g_press_event.last_press_is_long = is_long;
                    g_press_event.last_press_valid = 1u;

                    /* Visual classification: green for short, red for long. */
                    if (is_long) {
                        fputc(HW_LED_GREEN_OFF, hw);
                        fputc(HW_LED_RED_ON, hw);
                    } else {
                        fputc(HW_LED_RED_OFF, hw);
                        fputc(HW_LED_GREEN_ON, hw);
                    }
                }
            }
        }
    }
}