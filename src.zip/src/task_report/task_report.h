#pragma once

#include <stdint.h>

typedef struct {
    uint8_t  started;
    uint32_t last_report_tick;
} TaskReportCtx;

void task_report_init(TaskReportCtx* ctx);
void task_report_run(void* vctx);