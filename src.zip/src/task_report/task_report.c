#include "task_report.h"

#include "../app_shared/app_shared.h"
#include "../mcal_uart0_stdio/mcal_uart0_stdio.h"

#include <stdio.h>
#include <string.h>
#include <stdint.h>

#ifdef USE_FREERTOS
#include <Arduino_FreeRTOS.h>
#include <semphr.h>

/* Provided by rtos_tasks.c */
extern SemaphoreHandle_t g_mutex_shared;
#endif

typedef struct {
    uint32_t total;
    uint32_t short_count;
    uint32_t long_count;
    uint32_t sum_ms;
} StatsSnap;

static uint8_t is_ws(char c) {
    return (c == ' ') || (c == '\t') || (c == '\r') || (c == '\n');
}
static const char* skip_ws(const char* p) {
    while (*p && is_ws(*p)) p++;
    return p;
}
static void rtrim(char* s) {
    size_t n = strlen(s);
    while (n > 0) {
        char c = s[n - 1];
        if (!is_ws(c)) break;
        s[n - 1] = '\0';
        n--;
    }
}
static void read_token(const char* line, char* out, uint8_t out_sz) {
    if (out_sz == 0) return;
    out[0] = '\0';
    const char* p = skip_ws(line);
    uint8_t i = 0;
    while (*p && !is_ws(*p) && i < (uint8_t)(out_sz - 1u)) out[i++] = *p++;
    out[i] = '\0';
}
static uint8_t looks_like_user_command(const char* s) {
    for (; *s; s++) {
        char c = *s;
        if ((c >= 'a' && c <= 'z') ||
            (c >= 'A' && c <= 'Z') ||
            (c >= '0' && c <= '9')) return 1u;
    }
    return 0u;
}

static void stats_copy_locked(StatsSnap* out) {
    out->total       = g_stats.total;
    out->short_count = g_stats.short_count;
    out->long_count  = g_stats.long_count;
    out->sum_ms      = g_stats.sum_ms;
}

static void stats_reset_locked(void) {
    g_stats.total = 0;
    g_stats.short_count = 0;
    g_stats.long_count = 0;
    g_stats.sum_ms = 0;
}

static void print_snap_short(const StatsSnap* s) {
    uint32_t avg = (s->total ? (s->sum_ms / s->total) : 0u);
    /* Abbrev line: R T= total, S= short, L= long, A= avg(ms) */
    printf("R T=%lu S=%lu L=%lu A=%lu\n",
           (unsigned long)s->total,
           (unsigned long)s->short_count,
           (unsigned long)s->long_count,
           (unsigned long)avg);
}

static void console_poll(void) {
    char line[48];
    if (!mcal_stdio_try_readline(line, sizeof(line))) return;

    rtrim(line);
    const char* p = skip_ws(line);
    if (*p == '\0') return;
    if (!looks_like_user_command(p)) return;

    char cmd[16];
    read_token(p, cmd, sizeof(cmd));
    if (cmd[0] == '\0') return;

    if (strcmp(cmd, "stats") == 0) {
        StatsSnap snap;

#ifdef USE_FREERTOS
        xSemaphoreTake(g_mutex_shared, portMAX_DELAY);
        stats_copy_locked(&snap);
        xSemaphoreGive(g_mutex_shared);
#else
        stats_copy_locked(&snap);
#endif
        /* Print UNLOCKED */
        print_snap_short(&snap);
        return;
    }

    if (strcmp(cmd, "reset") == 0) {
#ifdef USE_FREERTOS
        xSemaphoreTake(g_mutex_shared, portMAX_DELAY);
        stats_reset_locked();
        xSemaphoreGive(g_mutex_shared);
#else
        stats_reset_locked();
#endif
        /* Print UNLOCKED */
        printf("OK\n");
        return;
    }

    printf("stats|reset\n");
}

void task_report_init(TaskReportCtx* ctx) {
    if (!ctx) return;
    ctx->started = 0u;
    ctx->last_report_tick = 0u;
}

void task_report_run(void* vctx) {
    TaskReportCtx* ctx = (TaskReportCtx*)vctx;

    console_poll();
    if (!ctx) return;

#ifdef USE_FREERTOS
    const uint32_t now_tick = (uint32_t)xTaskGetTickCount();
    const uint32_t ten_sec_ticks = (uint32_t)pdMS_TO_TICKS(10000);

    if (!ctx->started) {
        ctx->started = 1u;
        ctx->last_report_tick = now_tick;
        return;
    }

    if ((uint32_t)(now_tick - ctx->last_report_tick) >= ten_sec_ticks) {
        StatsSnap snap;

        /* LOCK only for copy+reset */
        xSemaphoreTake(g_mutex_shared, portMAX_DELAY);
        stats_copy_locked(&snap);
        stats_reset_locked();
        xSemaphoreGive(g_mutex_shared);

        /* Print UNLOCKED so button task won't block on UART printing */
        print_snap_short(&snap);

        ctx->last_report_tick = now_tick;
    }
#else
    /* Bare-metal: print+reset each time you call it (scheduler decides 10s). */
    StatsSnap snap;
    stats_copy_locked(&snap);
    stats_reset_locked();
    print_snap_short(&snap);
#endif
}