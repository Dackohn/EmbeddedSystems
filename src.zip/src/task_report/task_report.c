/*
 * task_report.c
 *
 * Task 3:
 * - prints periodic report over UART (stdout)
 * - resets statistics after each periodic report (new 10s window)
 * - polls UART for simple commands:
 *     "stats" -> print snapshot without reset
 *     "reset" -> clear statistics immediately
 */

#include "task_report.h"
#include "../app_shared/app_shared.h"
#include "../mcal_uart0_stdio/mcal_uart0_stdio.h"
#include <stdio.h>
#include <string.h>

/* Reset all counters for a new measurement window. */
static void reset_stats(void) {
    g_stats.total = 0;
    g_stats.short_count = 0;
    g_stats.long_count = 0;
    g_stats.sum_ms = 0;
}

/* Print a snapshot with a tag (periodic/manual). */
static void print_stats(const Stats_t* s, const char* tag) {
    uint32_t avg = 0;
    if (s->total) avg = s->sum_ms / s->total;

    printf("\n[%s]\n", tag);
    printf("total=%lu short=%lu long=%lu avg=%lu ms\n",
           (unsigned long)s->total,
           (unsigned long)s->short_count,
           (unsigned long)s->long_count,
           (unsigned long)avg);
}

/* Poll UART for a full line and execute recognized commands. */
static void console_poll(void) {
    char line[48];

    if (!mcal_stdio_try_readline(line, sizeof(line))) return;

    if (strcmp(line, "stats") == 0) {
        /* Snapshot avoids partial reads if values change during printing. */
        Stats_t snap = g_stats;
        print_stats(&snap, "manual stats");
    } else if (strcmp(line, "reset") == 0) {
        reset_stats();
        printf("OK: reset\n");
    } else if (line[0]) {
        printf("Commands: stats | reset\n");
    }
}

void task_report_init(TaskReportCtx* ctx) {
    (void)ctx;
}

void task_report_run(void* vctx) {
    (void)vctx;

    /* Periodic report required by the lab. */
    Stats_t snap = g_stats;
    print_stats(&snap, "10s report");

    /* Reset after reporting to start a new monitoring window. */
    reset_stats();

    /* Optional: handle user commands (non-blocking). */
    console_poll();
}