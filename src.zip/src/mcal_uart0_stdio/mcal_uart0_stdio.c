/*
 * mcal_uart0_stdio.c
 *
 * UART0 driver integrated with stdio:
 * - stdout/stdin are redirected so printf() prints to UART
 * - provides a non-blocking line reader used for simple console commands
 */

#include "mcal_uart0_stdio.h"
#include <avr/io.h>
#include <stdio.h>

/* putchar handler for stdout: blocks until UART can transmit. */
static int uart_putchar(char c, FILE* stream) {
    (void)stream;
    while (!(UCSR0A & (1 << UDRE0))) { }
    UDR0 = (uint8_t)c;
    return 0;
}

/* getchar handler for stdin: blocks until a byte is received. */
static int uart_getchar(FILE* stream) {
    (void)stream;
    while (!(UCSR0A & (1 << RXC0))) { }
    return (int)UDR0;
}

static FILE g_uart_stream;

void mcal_uart0_stdio_init(uint32_t baud) {
    /* Baud divisor (standard AVR UART formula). */
    uint16_t ubrr = (uint16_t)((F_CPU / (16UL * baud)) - 1UL);

    UBRR0H = (uint8_t)(ubrr >> 8);
    UBRR0L = (uint8_t)(ubrr & 0xFFu);

    /* Enable TX and RX. */
    UCSR0B = (1 << TXEN0) | (1 << RXEN0);

    /* 8N1 frame format. */
    UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);

    /* Bind UART handlers to stdio streams. */
    fdev_setup_stream(&g_uart_stream, uart_putchar, uart_getchar, _FDEV_SETUP_RW);
    stdout = &g_uart_stream;
    stdin  = &g_uart_stream;
}

/*
 * Non-blocking console line reader:
 * - If no RX byte is available, return 0 immediately.
 * - Collects chars until CR/LF, then outputs a null-terminated string.
 */
uint8_t mcal_stdio_try_readline(char* out, uint8_t out_sz) {
    static char buf[48];
    static uint8_t idx = 0;

    if (!(UCSR0A & (1 << RXC0))) return 0u;

    char c = (char)UDR0;

    if (c == '\n' || c == '\r') {
        if (idx >= sizeof(buf)) idx = (uint8_t)(sizeof(buf) - 1u);
        buf[idx] = '\0';

        uint8_t n = (idx < (uint8_t)(out_sz - 1u)) ? idx : (uint8_t)(out_sz - 1u);
        for (uint8_t i = 0; i < n; i++) out[i] = buf[i];
        out[n] = '\0';

        idx = 0;
        return 1u;
    }

    if (idx < (uint8_t)(sizeof(buf) - 1u)) {
        buf[idx++] = c;
    }
    return 0u;
}