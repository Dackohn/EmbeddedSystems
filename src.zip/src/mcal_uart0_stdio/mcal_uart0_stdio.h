#pragma once
#include <stdint.h>

/* Initialize UART0 and attach it to stdin/stdout (printf/scanf). */
void mcal_uart0_stdio_init(uint32_t baud);

/* Non-blocking line reader: returns 1 when a full line is available. */
uint8_t mcal_stdio_try_readline(char* out, uint8_t out_sz);