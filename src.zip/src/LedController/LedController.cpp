#include "LedController.h"

static void Led_Set(const Led *led, LedState state)
{
    *(led->Ddr) |= led->PinMask; // output
    if (state == LedState_On)
    {
        *(led->Port) |= led->PinMask;
    }
    else
    {
        *(led->Port) &= (uint8_t)~led->PinMask;
    }
}

void LedController_Init(LedController *ctx, Led green, Led red)
{
    ctx->Green = green;
    ctx->Red = red;
    Led_Set(&ctx->Green, LedState_Off);
    Led_Set(&ctx->Red, LedState_Off);
}

void LedController_SetGreen(LedController *ctx, LedState state)
{
    Led_Set(&ctx->Green, state);
}

void LedController_SetRed(LedController *ctx, LedState state)
{
    Led_Set(&ctx->Red, state);
}

void LedController_AllOff(LedController *ctx)
{
    Led_Set(&ctx->Green, LedState_Off);
    Led_Set(&ctx->Red, LedState_Off);
}