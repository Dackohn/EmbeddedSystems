#ifndef LED_CONTROLLER_H
#define LED_CONTROLLER_H

#include <stdint.h>

typedef enum
{
    LedState_Off = 0,
    LedState_On  = 1
} LedState;

typedef struct
{
    volatile uint8_t *Ddr;
    volatile uint8_t *Port;
    uint8_t PinMask;
} Led;

typedef struct
{
    Led Green;
    Led Red;
} LedController;

void LedController_Init(LedController *ctx, Led green, Led red);
void LedController_SetGreen(LedController *ctx, LedState state);
void LedController_SetRed(LedController *ctx, LedState state);
void LedController_AllOff(LedController *ctx);

#endif