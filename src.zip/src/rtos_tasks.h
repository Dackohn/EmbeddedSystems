#pragma once

#ifdef USE_FREERTOS

void rtos_tasks_create(void);

#endif